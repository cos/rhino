exports.foo = require('c').foo;
